DEFINITION MODULE Circles;

(* EXPORT QUALIFIED AreaOfCircle, PerimeterOfCircle; *)

PROCEDURE AreaOfCircle(Radius : REAL; VAR Area : REAL);

PROCEDURE PerimeterOfCircle(Radius : REAL; VAR Perim : REAL);

END Circles.
